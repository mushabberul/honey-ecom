<div class="logo position-relative">
    <a href="{{route('admin.dashboard')}}">
       <img src="{{asset('assets/backend')}}/img/logo/logo-light.svg" alt="logo" />
    </a>
</div>

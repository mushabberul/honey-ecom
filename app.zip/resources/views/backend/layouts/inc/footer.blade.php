<footer>
    <div class="footer-content">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-6">
                    <p class="mb-0 text-muted text-medium">&copy; 2022 Honey Shop - All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>
